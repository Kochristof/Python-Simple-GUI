import PySimpleGUI as sg

#For more Demo Programs github-->PySimpleGUI
layout = [
    [sg.Text("Hello from PySimpleGUI")],
    [sg.Button("OK")]
]

window = sg.Window("Demo 2", layout, margins=(200,100))

while True:
    event, values = window.read()
    if event==OK or event==sg.WIN_CLOSED:
        break

window.close()